package Practica.EmpleosWalter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpleosWalterApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpleosWalterApplication.class, args);
	}

}
